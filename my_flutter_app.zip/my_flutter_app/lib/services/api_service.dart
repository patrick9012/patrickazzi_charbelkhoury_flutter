import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Change this to your computer's IP address when testing on physical device
  // For Android Emulator use: 10.0.2.2
  // For iOS Simulator use: localhost
  static const String baseUrl = 'http://192.168.0.134:3000/api';
  
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  static Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
  }

  static Future<void> removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }

  static Future<Map<String, String>> getHeaders() async {
    final token = await getToken();
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // Auth APIs
  static Future<Map<String, dynamic>> register(Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );
    
    if (response.statusCode == 201) {
      final responseData = json.decode(response.body);
      await saveToken(responseData['token']);
      return responseData;
    } else {
      throw Exception(json.decode(response.body)['error']);
    }
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'email': email, 'password': password}),
    );
    
    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      await saveToken(responseData['token']);
      return responseData;
    } else {
      throw Exception(json.decode(response.body)['error']);
    }
  }

  // User APIs
  static Future<Map<String, dynamic>> getProfile() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/user/profile'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load profile');
    }
  }

  static Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> data) async {
    final headers = await getHeaders();
    final response = await http.put(
      Uri.parse('$baseUrl/user/profile'),
      headers: headers,
      body: json.encode(data),
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to update profile');
    }
  }

  // Exercise APIs
  static Future<List<dynamic>> getExercises({String? muscleGroup, String? difficulty}) async {
    final headers = await getHeaders();
    String url = '$baseUrl/exercises';
    List<String> queryParams = [];
    
    if (muscleGroup != null) queryParams.add('muscleGroup=$muscleGroup');
    if (difficulty != null) queryParams.add('difficulty=$difficulty');
    
    if (queryParams.isNotEmpty) {
      url += '?${queryParams.join('&')}';
    }
    
    final response = await http.get(Uri.parse(url), headers: headers);
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load exercises');
    }
  }

  static Future<Map<String, dynamic>> getExercise(String id) async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/exercises/$id'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load exercise');
    }
  }

  // Workout APIs
  static Future<List<dynamic>> getWorkouts() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/workouts'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load workouts');
    }
  }

  static Future<Map<String, dynamic>> getWorkout(String id) async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/workouts/$id'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load workout');
    }
  }

  static Future<Map<String, dynamic>> createWorkout(Map<String, dynamic> data) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse('$baseUrl/workouts'),
      headers: headers,
      body: json.encode(data),
    );
    
    if (response.statusCode == 201) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to create workout');
    }
  }

  static Future<Map<String, dynamic>> updateWorkout(String id, Map<String, dynamic> data) async {
    final headers = await getHeaders();
    final response = await http.put(
      Uri.parse('$baseUrl/workouts/$id'),
      headers: headers,
      body: json.encode(data),
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to update workout');
    }
  }

  static Future<void> deleteWorkout(String id) async {
    final headers = await getHeaders();
    final response = await http.delete(
      Uri.parse('$baseUrl/workouts/$id'),
      headers: headers,
    );
    
    if (response.statusCode != 200) {
      throw Exception('Failed to delete workout');
    }
  }

  // Progress APIs
  static Future<List<dynamic>> getProgress({DateTime? startDate, DateTime? endDate}) async {
    final headers = await getHeaders();
    String url = '$baseUrl/progress';
    List<String> queryParams = [];
    
    if (startDate != null) {
      queryParams.add('startDate=${startDate.toIso8601String()}');
    }
    if (endDate != null) {
      queryParams.add('endDate=${endDate.toIso8601String()}');
    }
    
    if (queryParams.isNotEmpty) {
      url += '?${queryParams.join('&')}';
    }
    
    final response = await http.get(Uri.parse(url), headers: headers);
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load progress');
    }
  }

  static Future<Map<String, dynamic>> createProgress(Map<String, dynamic> data) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse('$baseUrl/progress'),
      headers: headers,
      body: json.encode(data),
    );
    
    if (response.statusCode == 201) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to create progress');
    }
  }

  // Stats APIs
  static Future<List<dynamic>> getStats() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/stats'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load stats');
    }
  }

  static Future<Map<String, dynamic>> createStats(Map<String, dynamic> data) async {
    final headers = await getHeaders();
    final response = await http.post(
      Uri.parse('$baseUrl/stats'),
      headers: headers,
      body: json.encode(data),
    );
    
    if (response.statusCode == 201) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to create stats');
    }
  }

  // Dashboard API
  static Future<Map<String, dynamic>> getDashboard() async {
    final headers = await getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl/dashboard'),
      headers: headers,
    );
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load dashboard');
    }
  }

  // Seed Database
  static Future<void> seedDatabase() async {
    final response = await http.post(
      Uri.parse('$baseUrl/seed'),
      headers: {'Content-Type': 'application/json'},
    );
    
    if (response.statusCode != 200) {
      throw Exception('Failed to seed database');
    }
  }
}