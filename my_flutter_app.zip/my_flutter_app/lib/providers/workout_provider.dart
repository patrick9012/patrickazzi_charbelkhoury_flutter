import 'package:flutter/foundation.dart';
import '../services/api_service.dart';

class WorkoutProvider with ChangeNotifier {
  List<dynamic> _workouts = [];
  Map<String, dynamic>? _currentWorkout;
  bool _isLoading = false;
  String? _error;

  List<dynamic> get workouts => _workouts;
  Map<String, dynamic>? get currentWorkout => _currentWorkout;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchWorkouts() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _workouts = await ApiService.getWorkouts();
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchWorkoutById(String id) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _currentWorkout = await ApiService.getWorkout(id);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> createWorkout(Map<String, dynamic> workoutData) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final newWorkout = await ApiService.createWorkout(workoutData);
      _workouts.insert(0, newWorkout);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateWorkout(String id, Map<String, dynamic> workoutData) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final updatedWorkout = await ApiService.updateWorkout(id, workoutData);
      final index = _workouts.indexWhere((w) => w['_id'] == id);
      if (index != -1) {
        _workouts[index] = updatedWorkout;
      }
      _currentWorkout = updatedWorkout;
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteWorkout(String id) async {
    try {
      await ApiService.deleteWorkout(id);
      _workouts.removeWhere((w) => w['_id'] == id);
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  void clearCurrentWorkout() {
    _currentWorkout = null;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}