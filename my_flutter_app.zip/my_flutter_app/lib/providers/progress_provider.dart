import 'package:flutter/foundation.dart';
import '../services/api_service.dart';

class ProgressProvider with ChangeNotifier {
  List<dynamic> _progressList = [];
  Map<String, dynamic>? _dashboardData;
  bool _isLoading = false;
  String? _error;

  List<dynamic> get progressList => _progressList;
  Map<String, dynamic>? get dashboardData => _dashboardData;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchProgress({DateTime? startDate, DateTime? endDate}) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _progressList = await ApiService.getProgress(
        startDate: startDate,
        endDate: endDate,
      );
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> logProgress(Map<String, dynamic> progressData) async {
    try {
      final newProgress = await ApiService.createProgress(progressData);
      _progressList.insert(0, newProgress);
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<void> fetchDashboard() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _dashboardData = await ApiService.getDashboard();
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  int getTotalWorkouts() {
    return _dashboardData?['totalWorkouts'] ?? 0;
  }

  int getWorkoutsThisMonth() {
    return _dashboardData?['workoutsThisMonth'] ?? 0;
  }

  double getTotalCalories() {
    return (_dashboardData?['totalCaloriesBurned'] ?? 0).toDouble();
  }

  double getTotalDuration() {
    return (_dashboardData?['totalDuration'] ?? 0).toDouble();
  }

  List<dynamic> getRecentProgress() {
    return _dashboardData?['recentProgress'] ?? [];
  }
}