import 'package:flutter/foundation.dart';
import '../services/api_service.dart';

class ExerciseProvider with ChangeNotifier {
  List<dynamic> _exercises = [];
  bool _isLoading = false;
  String? _error;

  List<dynamic> get exercises => _exercises;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchExercises({String? muscleGroup, String? difficulty}) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _exercises = await ApiService.getExercises(
        muscleGroup: muscleGroup,
        difficulty: difficulty,
      );
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>> getExerciseById(String id) async {
    try {
      return await ApiService.getExercise(id);
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }

  List<String> getMuscleGroups() {
    final groups = _exercises
        .map((e) => e['muscleGroup'] as String?)
        .where((g) => g != null)
        .toSet()
        .toList();
    return groups.cast<String>();
  }

  List<dynamic> filterExercises(String? muscleGroup, String? difficulty) {
    return _exercises.where((exercise) {
      bool matchesMuscle = muscleGroup == null || 
                           muscleGroup == 'All' || 
                           exercise['muscleGroup'] == muscleGroup;
      bool matchesDifficulty = difficulty == null || 
                               difficulty == 'All' || 
                               exercise['difficulty'] == difficulty;
      return matchesMuscle && matchesDifficulty;
    }).toList();
  }
}